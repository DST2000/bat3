DROP TABLE IF EXISTS `#__batbrands`;

DROP TABLE IF EXISTS `#__batbrand_clients`;

DROP TABLE IF EXISTS `#__batbrand_tracks`;

